// Práctica 7 · Ensamble completo (Equipo 1). Unidades adimensionales: D = 1.
// Tramo de entrada L1 + venturi cónico + tramo intermedio L2 + codo de 90° + tramo de salida L3.
// Construido sobre el venturi.geo del tutorial 3.1.3 (secciones en O a escala, volúmenes transfinitos), la capa de
// pared y las longitudes del tutorial 3.1.2, y el codo por extrusión con rotación del 3.1.3.
// La entrada queda en z = 0, el eje de entrada en +z y el codo gira hacia +x, como en los tutoriales.
// En blueCFD, después de gmshToFoam:  transformPoints "Ry=90, Rx=90"
// Desde la terminal:  gmsh ensamble.geo -3 -setnumber regimen 0 -setnumber malla 2 -o lam_M2.msh

SetFactory("Built-in");

DefineConstant[
  regimen = {0, Choices{0 = "Laminar", 1 = "Turbulento"}, Name "Práctica 7/1Régimen"},
  malla   = {3, Choices{1 = "Fina (M1)", 2 = "Media (M2)", 3 = "Gruesa (M3)"}, Name "Práctica 7/2Malla (sólo laminar)"}
];

// ------------------------------------------------ combinación del Equipo 1 (Tabla 1 del manual)
ReLam  = 100;      // Reynolds laminar
ReTurb = 20000;    // Reynolds turbulento
beta   = 0.50;     // d/D
angC   = 21;       // ángulo total del convergente (grados), fijo en el manual
angD   = 15;       // ángulo total del difusor (grados)
RcD    = 1.5;      // radio de curvatura del codo, Rc/D

// ------------------------------------------------ parámetros de malla (Tabla 2 del manual)
If (malla == 1)
  nq = 15;  dz = 0.167;  yplus = 0.13;  gmax = 1.13;
ElseIf (malla == 3)
  nq = 7;   dz = 0.375;  yplus = 0.30;  gmax = 1.31;
Else
  nq = 10;  dz = 0.25;   yplus = 0.20;  gmax = 1.20;
EndIf
// Turbulento: una sola malla, con la resolución de la media y la primera celda para y+ = 1 (Parte V del manual).
If (regimen == 1)
  nq = 10;  dz = 0.25;  yplus = 1;  gmax = 1.20;
EndIf
dzv  = 0.40 * dz;      // celda axial en el venturi (0.1 D en la malla media, como el tutorial)
dsc  = 0.47 * dz;      // celda sobre el eje del codo (20 capas en la malla media, como el tutorial)

D = 1;  R = D / 2;  rm = 0.8 * R;  a = 0.4 * R;

// ------------------------------------------------ fricción, primera celda y longitudes (como el 3.1.2)
If (regimen == 0)
  Re = ReLam;
  f  = 64 / Re;
  Le = D * (0.619^1.6 + (0.0567 * Re)^1.6)^(1 / 1.6);    // Durst et al. (2005)
Else
  Re = ReTurb;
  f  = 1 / (0.790 * Log(Re) - 1.64)^2;                   // Petukhov
  Le = D * 4.4 * Re^(1 / 6);
EndIf
h1 = 2 * yplus * D / (Re * Sqrt(f / 8));
L1 = Le + 10 * D;      // tramo de entrada
L2 = Le + 5 * D;       // tramo intermedio
L3 = Le + 5 * D;       // tramo de salida
Rc = RcD * D;

// ------------------------------------------------ las cuatro estaciones del venturi
Lc = (1 - beta) * R / Tan(angC / 2 * Pi / 180);     // largo del convergente
Lt = beta * D;                                     // garganta: tan larga como su diámetro
Lv = (1 - beta) * R / Tan(angD / 2 * Pi / 180);     // largo del difusor
zs[] = {L1, L1 + Lc, L1 + Lc + Lt, L1 + Lc + Lt + Lv};
ss[] = {1, beta, beta, 1};                         // escala del radio en cada estación
nz[] = {Round(Lc / (dzv * D)), Round(Lt / (dzv * D)), Round(Lv / (dzv * D))};

// ------------------------------------------------ la capa de la pared, desde y+
Macro Razon
  rA = 1.0 + 1.e-9;  rB = 3.0;
  For iter In {1:80}
    rM = 0.5 * (rA + rB);
    sM = eh1 * (rM^(eN - 1) - 1.0) / (rM - 1.0);
    If (sM < eL)
      rA = rM;
    Else
      rB = rM;
    EndIf
  EndFor
  eR = 0.5 * (rA + rB);
Return
eL = R - rm;  eh1 = h1;
eN = 1 + Ceil(Log(1 + eL * (gmax - 1) / h1) / Log(gmax));
Call Razon;
nb = eN;  g = eR;
nr = Round((rm - a) / (2 * a / nq));

// ------------------------------------------------ capas axiales de cada pieza
nL1 = Round(L1 / (dz * D));
nL2 = Round(L2 / (dz * D));
nL3 = Round(L3 / (dz * D));
nc  = Round((Pi / 2 * Rc) / (dsc * D));
zA  = zs[3] + L2;                 // z donde empieza el codo
xo  = Rc + L3;                    // x de la salida
zc  = zA + Rc;                    // z del eje del tramo de salida
Nsec = nq^2 + 4 * nq * nr + 4 * nq * (nb - 1);
Ncap = nL1 + nz[0] + nz[1] + nz[2] + nL2 + nc + nL3;

Printf("Re = %g   f = %g   Le = %g D", Re, f, Le / D);
Printf("L1 = %g D   L2 = %g D   L3 = %g D   Rc = %g D", L1 / D, L2 / D, L3 / D, Rc / D);
Printf("venturi: convergente %g D, garganta %g D, difusor %g D", Lc, Lt, Lv);
Printf("y+ = %g -> primera celda h1 = %g D; anillo de %g celdas con razón %g", yplus, h1, nb - 1, g);
Printf("capas: entrada %g, venturi %g + %g + %g, intermedio %g, codo %g, salida %g", nL1, nz[0], nz[1], nz[2], nL2, nc, nL3);
Printf("celdas por sección: %g   celdas previstas: %g", Nsec, Nsec * Ncap);
Printf("posiciones s/D sobre el eje: fin de L1 = %g, garganta (centro) = %g, fin del venturi = %g, inicio del codo = %g, fin del codo = %g, salida = %g",
       L1, zs[1] + Lt / 2, zs[3], zA, zA + Pi / 2 * Rc, zA + Pi / 2 * Rc + L3);

// ------------------------------------------------ una sección en cada estación (venturi.geo, tutorial 3.1.3)
// Numeración local de la sección (la del 3.1.1): puntos 1 a 13, líneas 1 a 12, arcos 13 a 20, superficies 1 a 9.
// La estación k suma 100 k a todos los números.
I[] = {2,3,4,5, 2,3,4,5, 6,7,8,9, 6,7,8,9, 10,11,12,13};    // punto inicial de las curvas 1 a 20
F[] = {3,4,5,2, 6,7,8,9, 10,11,12,13, 7,8,9,6, 11,12,13,10}; // punto final
LZ[] = {1,2,3,4,  1,6,-13,-5,  2,7,-14,-6,  3,8,-15,-7,  4,5,-16,-8,
        13,10,-17,-9,  14,11,-18,-10,  15,12,-19,-11,  16,9,-20,-12};    // lazos de las 9 superficies
c45 = Cos(Pi / 4);
For k In {0:3}
  z = zs[k];  s = ss[k];  p = 100 * k;
  Point(p+1) = {0, 0, z};
  Point(p+2) = {s*a, s*a, z};  Point(p+3) = {-s*a, s*a, z};  Point(p+4) = {-s*a, -s*a, z};  Point(p+5) = {s*a, -s*a, z};
  Point(p+6) = {s*rm*c45, s*rm*c45, z};   Point(p+7) = {-s*rm*c45, s*rm*c45, z};
  Point(p+8) = {-s*rm*c45, -s*rm*c45, z}; Point(p+9) = {s*rm*c45, -s*rm*c45, z};
  Point(p+10) = {s*R*c45, s*R*c45, z};    Point(p+11) = {-s*R*c45, s*R*c45, z};
  Point(p+12) = {-s*R*c45, -s*R*c45, z};  Point(p+13) = {s*R*c45, -s*R*c45, z};
  For cu In {1:12}
    Line(p+cu) = {p+I[cu-1], p+F[cu-1]};
  EndFor
  For cu In {13:20}
    Circle(p+cu) = {p+I[cu-1], p+1, p+F[cu-1]};
  EndFor
  For b In {0:8}
    Curve Loop(p+b+1) = {(LZ[4*b]/Fabs(LZ[4*b]))*(p+Fabs(LZ[4*b])), (LZ[4*b+1]/Fabs(LZ[4*b+1]))*(p+Fabs(LZ[4*b+1])),
                         (LZ[4*b+2]/Fabs(LZ[4*b+2]))*(p+Fabs(LZ[4*b+2])), (LZ[4*b+3]/Fabs(LZ[4*b+3]))*(p+Fabs(LZ[4*b+3]))};
    Plane Surface(p+b+1) = {p+b+1};
  EndFor
  Transfinite Curve{p+1:p+4, p+13:p+20} = nq + 1;
  Transfinite Curve{p+5:p+8} = nr + 1;
  Transfinite Curve{p+9:p+12} = nb Using Progression 1 / g;
EndFor

// ------------------------------------------------ bloques entre estaciones (venturi)
For k In {0:2}
  p = 100 * k;  q = 100 * (k + 1);  L0 = 1000 * (k + 1);
  For j In {2:13}
    Line(L0 + j) = {p + j, q + j};
    Transfinite Curve{L0 + j} = nz[k] + 1;
  EndFor
  For cu In {1:20}
    Curve Loop(L0 + 100 + cu) = {p + cu, L0 + F[cu-1], -(q + cu), -(L0 + I[cu-1])};
    Surface(L0 + 100 + cu) = {L0 + 100 + cu};
  EndFor
  For b In {0:8}
    lat[] = {};
    For m In {0:3}
      lat[] += L0 + 100 + Fabs(LZ[4*b+m]);
    EndFor
    Surface Loop(L0 + b + 1) = {p + b + 1, q + b + 1, lat[]};
    Volume(L0 + b + 1) = {L0 + b + 1};
  EndFor
EndFor
Transfinite Surface{:};
Recombine Surface{:};
Transfinite Volume{:};

// ------------------------------------------------ tramo de entrada: de la primera estación hacia z = 0
antes[] = Extrude {0, 0, -L1} { Surface{1:9}; Layers{nL1}; Recombine; };

// ------------------------------------------------ tramo intermedio: de la última estación hacia +z
medio[] = Extrude {0, 0, L2} { Surface{301:309}; Layers{nL2}; Recombine; };
tapaM[] = {};
For i In {0:8}
  tapaM[] += medio[6 * i];        // las nueve caras del extremo del tramo intermedio
EndFor

// ------------------------------------------------ codo de 90°: giro alrededor de un eje paralelo a y, hacia +x
codo[] = Extrude {{0, 1, 0}, {Rc, 0, zA}, Pi / 2} { Surface{tapaM[]}; Layers{nc}; Recombine; };
tapaC[] = {};
For i In {0:8}
  tapaC[] += codo[6 * i];         // las nueve caras del extremo del codo
EndFor

// ------------------------------------------------ tramo de salida, en +x
final[] = Extrude {L3, 0, 0} { Surface{tapaC[]}; Layers{nL3}; Recombine; };

// ------------------------------------------------ grupos físicos, por posición (tutorial 3.1.3)
eps = 1e-6;
entrada[] = Surface In BoundingBox {-1, -1, -eps, 1, 1, eps};
salida[]  = Surface In BoundingBox {xo - eps, -1, zc - 1, xo + eps, 1, zc + 1};
pared[]   = Abs(CombinedBoundary{ Volume{:}; });
pared[]  -= entrada[];
pared[]  -= salida[];
Physical Surface("inlet")  = {entrada[]};
Physical Surface("outlet") = {salida[]};
Physical Surface("walls")  = {pared[]};
Physical Volume("fluid")   = {Volume{:}};
Mesh.MshFileVersion = 2.2;
